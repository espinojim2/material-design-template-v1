<?php

echo '
<link href="http://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet" type="text/css">
<link href="'.$base_url.'resources/fonts/googleapis.com/icon.css" rel="stylesheet">
<link href="'.$base_url.'resources/css/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
<link href="'.$base_url.'resources/materialize.min.css" type="text/css" rel="stylesheet"  media="screen,projection">
    





<script type="text/javascript" src="'.$base_url.'resources/jquery.min.js"></script>
<script type="text/javascript" src="'.$base_url.'resources/materialize.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$(".button-collapse").sideNav(); 
});
function actsidenavhid(){
  $(".button-collapse").sideNav("hide");
}
      </script>
';


?>