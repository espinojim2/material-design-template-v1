<?php

/* Database Config*/
$config['hostname'] = 'localhost';
$config['username'] = 'root';
$config['password'] = 'Warzed2@yahoo.com';
$config['database'] = 'accountingv2_contruct_6_18_2016';


extract($config);



?>