<?php

//if(isset($_SERVER['HTTP_HOST']))
//{
 //   $config['base_url'] = isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on' ? 'https' : 'http';
  //  $config['base_url'] .= '://'. $_SERVER['SERVER_NAME'];
  //  $config['base_url'] .= str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
//}
//else {
$config['base_url']	= 'http://localhost/project_material1.0/';
//}


extract($config);
?>