<html>

<head>
<?php
require("../../config/config.php");
require("../../links/links.php");

?>

  <style>
   
    
  </style>
</head>

<body>

 <div class="row">
      <div class="col s12 m5">
        <div class="card-panel gray">
          <span class="white-text">












          </span>
        </div>
      </div>
    </div>
            
 
</body>

</html>