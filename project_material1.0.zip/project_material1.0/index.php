<!DOCTYPE html>
  <html>
    <head>
      <title>Index Page</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">

    <link href="http://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet" type="text/css">
    <link href="resources/fonts/googleapis.com/icon.css" rel="stylesheet">
    <link href="resources/css/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="resources/materialize.min.css" type="text/css" rel="stylesheet"  media="screen,projection">
    



    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="theme-color" content="#EE6E73">
    <style type="text/css">
     header, main, footer {
      padding-left: 300px;
    }

    @media only screen and (max-width : 992px) {
      header, main, footer {
        padding-left: 0;
      }
    }


</style>
    </head>

    <body>

<nav style='position:fixed; z-index:100; box-shadow:none;'>
    <div class="nav-wrapper blue darken-1">
        <a href="#" data-activates="slide-out" style='display:block;' class="button-collapse"><i  class="material-icons">menu</i></a>

        <a href="#" class="brand-logo center">Logo</a>
     
    </div>
  </nav>
 


        <ul id="slide-out" class="side-nav">
        <li>
          <a href='#' class='right' style='margin:0;' onclick='actsidenavhid()'><i style='margin-right:0;' class="material-icons ">close</i></a>
          <div class="userView">

            <img class="background" src="images/office.jpg">
            <a href="#!user"><img class="circle" src="images/yuna.jpg"></a>
            <a href="#!name"><span class="white-text name">John Doe</span></a>
            <a href="#!email"><span class="white-text email">jdandturk@gmail.com</span></a>
          </div>
        </li>


         <li class="bold active"><a href="getting-started.html" class="waves-effect waves-teal ">Dashboard</a></li>
        <li class="bold "><a href="getting-started.html" class="waves-effect waves-teal ">My Profile</a></li>
        <li class="no-padding">
          <ul class="collapsible collapsible-accordion">
            <li class="bold"><a class="collapsible-header  waves-effect waves-teal">CSS</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="color.html">Color</a></li>
                  <li><a href="grid.html">Grid</a></li>
                  <li><a href="helpers.html">Helpers</a></li>
                  <li><a href="media-css.html">Media</a></li>
                  <li><a href="sass.html">Sass</a></li>
                  <li><a href="shadow.html">Shadow</a></li>
                  <li><a href="table.html">Table</a></li>
                  <li><a href="typography.html">Typography</a></li>
                </ul>
              </div>
            </li>
            <li class="bold"><a class="collapsible-header  waves-effect waves-teal">Items Management</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="badges.html">Badges</a></li>
                  <li><a href="buttons.html">Buttons</a></li>
                  <li><a href="breadcrumbs.html">Breadcrumbs</a></li>
                  <li><a href="cards.html">Cards</a></li>
                  <li><a href="chips.html">Chips</a></li>
                  <li><a href="collections.html">Collections</a></li>
                  <li><a href="footer.html">Footer</a></li>
                  <li><a href="forms.html">Forms</a></li>
                  <li><a href="icons.html">Icons</a></li>
                  <li><a href="navbar.html">Navbar</a></li>
                  <li><a href="pagination.html">Pagination</a></li>
                  <li><a href="preloader.html">Preloader</a></li>
                </ul>
              </div>
            </li>
            <li class="bold"><a class="collapsible-header  waves-effect waves-teal">Page Management</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="carousel.html">Page Setup</a></li>
                  <li><a href="collapsible.html">Page Authorization</a></li>
                  
                </ul>
              </div>
            </li>
          </ul>
        </li>
      </ul>

<nav style='box-shadow:none; opacity:0;'>
    <div class="nav-wrapper blue darken-1">
        <a href="#" data-activates="slide-out" style='display:block;' class="button-collapse"><i  class="material-icons">menu</i></a>

        <a href="#" class="brand-logo center">Logo</a>
     
    </div>
  </nav>
 <nav style='box-shadow:none; '>
    <div class="nav-wrapper blue darken-2" style='padding-left:1%;  padding-right:1%; '>
      <div class="col s12 push-s12" >
        <a href="#!" class="breadcrumb" style='font-size:15px;'>Inventory System</a>
        <a href="#!" class="breadcrumb" style='font-size:15px;'>Dashboard</a>
        
      </div>
    </div>
  </nav>



<div style='padding:1%;'>

  <center>
     <div class="preloader-wrapper big active">
      <div class="spinner-layer spinner-blue">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-red">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-yellow">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-green">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>
    </div>
    </center>


</div>








  
    
    </body>


      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="resources/jquery.min.js"></script>
      <script type="text/javascript" src="resources/materialize.min.js"></script>
      <script type="text/javascript">
$(document).ready(function(){
$('.button-collapse').sideNav(); 
});
function actsidenavhid(){
  $('.button-collapse').sideNav('hide');
}
      </script>
  </html>
        